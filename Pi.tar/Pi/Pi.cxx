#include <itkMath.h>

int main(int, char*[])
{
  std::cout << itk::Math::pi << std::endl;
  
  return EXIT_SUCCESS;
}
