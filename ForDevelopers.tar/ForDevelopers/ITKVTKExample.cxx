// Insert your c++ code here
#include <QuickView.h>
int main (int argc, char *argv[])
{
  return EXIT_SUCCESS;
}
