#ifndef __itkImageFilter_txx
#define __itkImageFilter_txx

#include "ImageFilterX.h"
#include "itkObjectFactory.h"
#include "itkImageRegionIterator.h"
#include "itkImageRegionConstIterator.h"

namespace itk
{

template< class TImage>
void ImageFilter< TImage>
::GenerateData()
{

}

}// end namespace


#endif
